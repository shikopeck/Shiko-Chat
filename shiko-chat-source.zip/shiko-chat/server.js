require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new Database("shiko-chat.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 plan TEXT NOT NULL DEFAULT 'basic',
 can_use_stickers INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 ciphertext TEXT NOT NULL,
 iv TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const username = process.env.ADMIN_USERNAME || "shikopeck";
const adminPassword = process.env.ADMIN_PASSWORD;
if (!adminPassword || adminPassword === "SET_A_NEW_STRONG_PASSWORD_HERE") {
  console.error("Set ADMIN_PASSWORD in .env before starting the server.");
  process.exit(1);
}
const existingAdmin = db.prepare("SELECT id FROM users WHERE username=?").get(username);
if (!existingAdmin) {
  db.prepare("INSERT INTO users(username,password_hash,role,plan) VALUES(?,?,?,?)")
    .run(username, bcrypt.hashSync(adminPassword, 12), "admin", "admin");
}

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://cdn.socket.io"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      connectSrc: ["'self'", "ws:", "wss:"],
      imgSrc: ["'self'", "data:"]
    }
  }
}));
app.use(express.json({limit:"20kb"}));
app.use(session({
  store: new SQLiteStore({ db: "sessions.db", dir: "." }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 8*60*60*1000 }
}));
app.use("/api", rateLimit({windowMs: 15*60*1000, limit: 150}));
app.use(express.static(path.join(__dirname, "public")));

const publicUser = u => ({id:u.id, username:u.username, role:u.role, plan:u.plan, canUseStickers:!!u.can_use_stickers});
function auth(req,res,next){ if(!req.session.user) return res.status(401).json({error:"سجّل الدخول أولاً"}); next(); }
function admin(req,res,next){ if(req.session.user?.role!=="admin") return res.status(403).json({error:"هذه الصفحة للإدارة فقط"}); next(); }

app.post("/api/register", async (req,res)=>{
  const name=String(req.body.username||"").trim();
  const pass=String(req.body.password||"");
  if(!/^[a-zA-Z0-9_]{3,20}$/.test(name) || pass.length<10 || pass.length>100)
    return res.status(400).json({error:"اسم المستخدم 3–20 حرفاً، وكلمة المرور 10 أحرف على الأقل"});
  try {
    const hash=await bcrypt.hash(pass,12);
    const result=db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(name,hash);
    const u=db.prepare("SELECT * FROM users WHERE id=?").get(result.lastInsertRowid);
    req.session.user=publicUser(u); res.json({user:req.session.user});
  } catch { res.status(409).json({error:"اسم المستخدم مستخدم بالفعل"}); }
});
app.post("/api/login", async (req,res)=>{
  const name=String(req.body.username||"").trim();
  const pass=String(req.body.password||"");
  const u=db.prepare("SELECT * FROM users WHERE username=?").get(name);
  if(!u || !(await bcrypt.compare(pass,u.password_hash))) return res.status(401).json({error:"بيانات الدخول غير صحيحة"});
  req.session.user=publicUser(u); res.json({user:req.session.user});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({user:req.session.user||null}));
app.get("/api/messages",auth,(req,res)=>{
  const rows=db.prepare("SELECT id,username,ciphertext,iv,created_at FROM messages ORDER BY id DESC LIMIT 100").all().reverse();
  res.json({messages:rows});
});
app.get("/api/admin/users",auth,admin,(req,res)=>{
  res.json({users:db.prepare("SELECT id,username,role,plan,can_use_stickers,created_at FROM users ORDER BY id").all()});
});
app.patch("/api/admin/users/:id",auth,admin,(req,res)=>{
  const id=Number(req.params.id);
  const plan=["basic","plus","pro"].includes(req.body.plan)?req.body.plan:null;
  const stickers=typeof req.body.canUseStickers==="boolean"?(req.body.canUseStickers?1:0):null;
  if(!Number.isInteger(id) || id===req.session.user.id) return res.status(400).json({error:"اختيار غير صالح"});
  const u=db.prepare("SELECT id FROM users WHERE id=?").get(id);
  if(!u) return res.status(404).json({error:"المستخدم غير موجود"});
  if(plan) db.prepare("UPDATE users SET plan=? WHERE id=?").run(plan,id);
  if(stickers!==null) db.prepare("UPDATE users SET can_use_stickers=? WHERE id=?").run(stickers,id);
  const updated=db.prepare("SELECT id,username,role,plan,can_use_stickers,created_at FROM users WHERE id=?").get(id);
  res.json({user:updated});
});

const wrap = fn => (socket,next)=>fn(socket,next);
io.use((socket,next)=>{
  const sid=socket.handshake.headers.cookie||"";
  // Socket sessions are authenticated using the session ID cookie and the same server-side store.
  const cookie = require("cookie").parse(sid);
  const sidCookie = cookie["connect.sid"];
  if(!sidCookie) return next(new Error("سجّل الدخول"));
  const signature = require("cookie-signature");
  const raw = signature.unsign(decodeURIComponent(sidCookie).slice(2), process.env.SESSION_SECRET || "development-only-change-this-secret");
  if(!raw) return next(new Error("جلسة غير صالحة"));
  const store = new SQLiteStore({db:"sessions.db",dir:"."});
  store.get(raw,(err,s)=> {
    if(err || !s?.user) return next(new Error("سجّل الدخول"));
    socket.user=s.user; next();
  });
});
io.on("connection",socket=>{
  socket.on("message",payload=>{
    if(!payload || typeof payload.ciphertext!=="string" || typeof payload.iv!=="string" ||
       payload.ciphertext.length>12000 || payload.iv.length>100) return;
    const result=db.prepare("INSERT INTO messages(username,ciphertext,iv) VALUES(?,?,?)")
      .run(socket.user.username,payload.ciphertext,payload.iv);
    io.emit("message",{id:result.lastInsertRowid,username:socket.user.username,
      ciphertext:payload.ciphertext,iv:payload.iv,created_at:new Date().toISOString()});
  });
});
const port=Number(process.env.PORT||3000);
server.listen(port,()=>console.log(`SHIKO CHAT running on http://localhost:${port}`));
